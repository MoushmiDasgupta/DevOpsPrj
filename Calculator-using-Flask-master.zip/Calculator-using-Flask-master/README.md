<h1>Calculator using Flask</h1>
<p>This is my first project using flask.</p>
<p>In that project simply i performed four operations that is addition, substraction, multiplication and division</p>
