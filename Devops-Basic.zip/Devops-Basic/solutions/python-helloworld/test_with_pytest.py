## Define a test that will always pass successfully
def test_always_passes():
    assert True
